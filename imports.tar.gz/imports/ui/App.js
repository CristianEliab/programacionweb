import React, { Component } from 'react';
import TaskList from './components/TaskList.js';
import AccountsUIWrapper from './AccountsUIWrapper.js';

// App component - represents the whole app
export default class App extends Component {

  render() {
    return (
      <div className="App ">
        <div className="header">
          <AccountsUIWrapper />
        </div>
        <div className="container">
          <TaskList owner="Cristian" />
        </div>

      </div>
    );
  }
} 
